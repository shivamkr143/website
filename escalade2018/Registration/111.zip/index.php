<?php
//index.php

$error = '';
$teamname = '';
$college = '';
$lname = '';
$lnum = '';
$lemail = '';
$ladd = '';
$num1 = '';
$name1 = '';
$add1 = '';
$email1 = '';
$num2 = '';
$name2 = '';
$add2 = '';
$email2 = '';
$num3 = '';
$name3 = '';
$add3 = '';
$email3 = '';

function clean_text($string)
{
	$string = trim($string);
	$string = stripslashes($string);
	$string = htmlspecialchars($string);
	return $string;
}

if(isset($_POST["submit"]))
{
	if(empty($_POST["teamname"]))
	{
		$error .= '<p>Please Enter your Team Name</p>';
	}
	else
	{
		$teamname = clean_text($_POST["teamname"]);
		if(!preg_match("/^[a-zA-Z ]*$/",$teamname))
		{
			$error .= '<p>Only letters and white space allowed</p>';
		}
	}

	if(empty($_POST["college"]))
	{
		$error .= '<p>College Name is required</p>';
	}
	else
	{
		$projectname = clean_text($_POST["college"]);
	}

	if(empty($_POST["lname"]))
	{
		$error .= '<p>Please Enter Team Leader name</p>';
	}
	else
	{
		$category = clean_text($_POST["lname"]);
		if(!preg_match("/^[a-zA-Z ]*$/",$lname))
		{
			$error .= '<p>Only letters and white space allowed</p>';
		}
	}

  if(empty($_POST["lnum"]))
  {
    $error .= '<p>Phone no is required</p>';
  }
  else
  {
    $abstract = clean_text($_POST["lnum"]);
  }



	if(empty($_POST["lemail"]))
	{
		$error .= '<p>E-mail is required</p>';
	}
	else
	{
		$participants = clean_text($_POST["lemail"]);
		if(!filter_var($lemail, FILTER_VALIDATE_EMAIL))
		{
			$error .= '<p>Invalid email format</p>';
		}
	}

	if(empty($_POST["ladd"]))
	{
		$error .= '<p>Please Enter your Address</p>';
	}
	else
	{
		$name = clean_text($_POST["ladd"]);
	}

	if(empty($_POST["name1"]))
	{
		$error .= '<p>Please Enter Team Leader name</p>';
	}
	else
	{
		$category = clean_text($_POST["name1"]);
		if(!preg_match("/^[a-zA-Z ]*$/",$name1))
		{
			$error .= '<p>Only letters and white space allowed</p>';
		}
	}

  if(empty($_POST["num1"]))
  {
    $error .= '<p>Phone no is required</p>';
  }
  else
  {
    $abstract = clean_text($_POST["num1"]);
  }



	if(empty($_POST["email1"]))
	{
		$error .= '<p>E-mail is required</p>';
	}
	else
	{
		$participants = clean_text($_POST["email1"]);
		if(!filter_var($lemail, FILTER_VALIDATE_EMAIL))
		{
			$error .= '<p>Invalid email format</p>';
		}
	}

	if(empty($_POST["add1"]))
	{
		$error .= '<p>Please Enter your Address</p>';
	}
	else
	{
		$name = clean_text($_POST["add1"]);
	}
	
	if(empty($_POST["name2"]))
	{
		$error .= '<p>Please Enter Team Leader name</p>';
	}
	else
	{
		$category = clean_text($_POST["name2"]);
		if(!preg_match("/^[a-zA-Z ]*$/",$name2))
		{
			$error .= '<p>Only letters and white space allowed</p>';
		}
	}

  if(empty($_POST["num2"]))
  {
    $error .= '<p>Phone no is required</p>';
  }
  else
  {
    $abstract = clean_text($_POST["num2"]);
  }



	if(empty($_POST["email2"]))
	{
		$error .= '<p>E-mail is required</p>';
	}
	else
	{
		$participants = clean_text($_POST["email1"]);
		if(!filter_var($email2, FILTER_VALIDATE_EMAIL))
		{
			$error .= '<p>Invalid email format</p>';
		}
	}

	if(empty($_POST["add2"]))
	{
		$error .= '<p>Please Enter your Address</p>';
	}
	else
	{
		$name = clean_text($_POST["add2"]);
	}
	
	
	if(empty($_POST["name3"]))
	{
		$error .= '<p>Please Enter Team Leader name</p>';
	}
	else
	{
		$category = clean_text($_POST["name3"]);
		if(!preg_match("/^[a-zA-Z ]*$/",$name3))
		{
			$error .= '<p>Only letters and white space allowed</p>';
		}
	}

  if(empty($_POST["num3"]))
  {
    $error .= '<p>Phone no is required</p>';
  }
  else
  {
    $abstract = clean_text($_POST["num3"]);
  }



	if(empty($_POST["email3"]))
	{
		$error .= '<p>E-mail is required</p>';
	}
	else
	{
		$participants = clean_text($_POST["email3"]);
		if(!filter_var($email3, FILTER_VALIDATE_EMAIL))
		{
			$error .= '<p>Invalid email format</p>';
		}
	}

	if(empty($_POST["add3"]))
	{
		$error .= '<p>Please Enter your Address</p>';
	}
	else
	{
		$name = clean_text($_POST["add3"]);
	}
	
	
	
	
	
	}
	

	if($error == '')
	{
		$file_open = fopen("register_escalade.csv", "a");
		$no_rows = count(file("register_escalade.csv"));
		if($no_rows > 1)
		{
			$no_rows = ($no_rows - 1) + 1;
		}
		$form_data = array(
			'sr_no'		    =>	  $no_rows,
			'teamname'    =>    $teamname,
      'college'     =>    $college,
			'lname' =>    $lname,
			'lnum'    =>    $lnum,
      'lemail'    =>    $lemail,
			'ladd'        =>    $ladd,
			'name1' =>    $name1,
			'num1'    =>    $num1,
      'email1'    =>    $email1,
			'add1'        =>    $add1,
			'name2' =>    $name2,
			'num2'    =>    $num2,
      'email2'    =>    $email2,
			'add2'        =>    $add2,
			'name3' =>    $name3,
			'num3'    =>    $num3,
      'email3'    =>    $email3,
			'add3'        =>    $add3,
			
		);
		fputcsv($file_open, $form_data);
		$error = 'Congrats! You have registered successfully.';
		//Email Setup
		$conf_subject = 'Escalade Registration Confirmation Mail';
       
	   $message = "Line 1\r\nLine 2\r\nLine 3";
	   $message = wordwrap($message, 70, "\r\n");
	   
	   mail('ashwin.devanga@yahoo.com', 'My Subject', $message);
		
$teamname = '';
$college = '';
$lname = '';
$lnum = '';
$lemail = '';
$ladd = '';
$num1 = '';
$name1 = '';
$add1 = '';
$email1 = '';
$num2 = '';
$name2 = '';
$add2 = '';
$email2 = '';
$num3 = '';
$name3 = '';
$add3 = '';
$email3 = '';

    echo "<script type='text/javascript'>alert(\"$error\");</script>";
    $error ='';

	}

	   
	   
	   
	   
 ?>       
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Escalade - Techniche'18 IIT Guwahati</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    
    
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    
    <link rel="stylesheet" href="stylemain.css">
    <link rel="stylesheet" href="style.css">
	
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
    
    
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    
    
    
    
    <style>
     body,html, div, p, span {
    font-family: "Lato", sans-serif;
         margin:0;
         padding:0;
         
}
 
        
        
       
    </style>
    
    
    
    
    
    
    
    
    
    
    
    
</head>


<body id="body">
<nav id="navbar">

<span style="font-size:26px;cursor:pointer;display:inline-block;padding:15px;padding-left:30px;background-color:white;width:70px;height:70px;"><p  onclick="openNav()">ESCALADE</p></span>

<div class="logo">
    <a href="">
        <img src="img/Logo_Techniche2018_.png" alt="techniche">
    </a>
</div>
<button class="btn btn-primary">Log In</button>
<button class="btn btn-primary">SignUp</button>
<!--
<form action="" id="search-option">
    <span class="search"><input type="text"  class="search-input" placeholder="Search the website">
    <i onclick="search()" class="material-icons">&#xE8B6;</i></span>
</form> --> 


</nav>

<!-- Navbar Ends -->

<!-- content starts here -->

<div id="background">
    <div class="main" >
          <div class='login'>
          
          
  <form method="post">
	  <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Register for Escalade</h3>
	  <?php echo $error; ?>
	  <br>
	  <input name='teamname' placeholder='Team Name' type='text' required>
	  <input name='college' placeholder='College Name' type='text' required>
    <input name='lname' placeholder='Team Leader Name' type='text' required>
	  <input name='lnum' placeholder='Team Leader Phone no' type='text' required>
    <input name='lemail' placeholder='Team leader email' type='text' required>
    <input name='ladd' placeholder='Team Leader Address' type='text' required>
    <br><br><br><br>
	  <input name='name1' placeholder='Team Member 1 Name' type='text' required>
	  <input name='num1' placeholder='Team Member 1 Phone no' type='text' required>
    <input name='email1' placeholder='Team Member 1 email' type='text' required>
    <input name='add1' placeholder='Team Member 1 Address' type='text' required>
    <br><br><br><br>
    <input name='name2' placeholder='Team Member 2 Name' type='text' required>
	  <input name='num2' placeholder='Team Member 2 Phone no' type='text' required>
    <input name='email2' placeholder='Team Member 2 email' type='text' required>
    <input name='add2' placeholder='Team Member 2 Address' type='text' required>
    <br><br><br><br>
    <input name='name3' placeholder='Team Member 3 Name' type='text' required>
	  <input name='num3' placeholder='Team Member 3 Phone no' type='text' required>
    <input name='email3' placeholder='Team Member 3 email' type='text' required>
    <input name='add3' placeholder='Team Member 3 Address' type='text' required>
    <br><br>
	  <br><br>
	  <input name='submit' type='submit' value='Register'>
  </form>
</div>    
    </div>    
</div>




        


		
	
        

<script src="js/jquery-2.1.4.js"></script>


<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementsByClassName("submenu").style.height = "0" ;
    
}
    
var lastscrolpos = 0;
var scrolpos = 0;
 
    window.addEventListener('scroll',function(){
        
        
        scrolpos = window.scrollY; 
     
        
        if(scrolpos>150){
            document.getElementById('T18').style.backgroundColor = 'black';
           
        }
        else{
            document.getElementById('T18').style.backgroundColor = 'transparent';
           
        }
        
        if(scrolpos >= 610){
            document.getElementById("mySidenav").style.width = "250px";
        }
        else{
            document.getElementById("mySidenav").style.width = "0";
        }
        
        }
    )
</script>
<script src="main.js"></script>
 <script src="canvas-nest.js-master/dist/canvas-nest.js"></script>
  <script

  color="255,255,255"

  opacity='0.5'

  zIndex="-2"

  count="200"

  src="canvas-nest.js-master/dist/canvas-nest.js">

</script>
  
  <script type="text/javascript" src="fullPage.js-master/vendors/scrolloverflow.min.js"></script>

	<script type="text/javascript" src="fullPage.js-master/jquery.fullPage.js"></script>
	<script type="text/javascript" src="examples.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('#fullpage').fullpage({
			  
			  anchors: ['firstPage', 'secondPage', '3rdPage', '4thpage', 'lastPage'],
			  menu: '#menu',
			  continuousVertical: false
			});
		});
	</script>

  
   
  


    
</body>
</html>